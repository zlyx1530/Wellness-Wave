import org.junit.*;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.*;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.sql.*;
import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

import static org.junit.Assert.*;

public class DashboardServletTest {

    private WebDriver driver;
    private Connection connection;
    private Duration duration = Duration.ofSeconds(5);
    private final String BASE_URL = "http://ec2-3-133-147-230.us-east-2.compute.amazonaws.com:8080/WellnessWave";

    @Before
    public void setUp() {
        System.setProperty("webdriver.chrome.driver", "C:\\Users\\Zlyx\\Desktop\\webprojects\\Web Servlet Tools\\ChromeDriver\\chromedriver.exe");
        driver = new ChromeDriver();
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

        String url = "jdbc:mysql://ec2-3-133-147-230.us-east-2.compute.amazonaws.com:3306/WellnessWave";
        String username = "newmysqlremoteuser";
        String password = "mypassword";
        try {
            connection = DriverManager.getConnection(url, username, password);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @After
    public void tearDown() {
        if (driver != null) {
            driver.quit();
        }
        if (connection != null) {
            try {
                deleteWellnessData("testuser");
                deleteUser("testuser");

                connection.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }

    @Test
    public void testDashboard_NoLoggedInUser() {
        driver.get(BASE_URL + "/dashboard");

        assertTrue(driver.getCurrentUrl().endsWith("/login"));
    }

    @Test
    public void testDashboard_LoggedInUser_NoData() {
        insertUser("testuser", "password");

        login("testuser", "password");

        driver.get(BASE_URL + "/dashboard");

        List<WebElement> wellnessDataTable = driver.findElements(By.xpath("//table/tbody/tr"));
        assertEquals(0, wellnessDataTable.size());
    }


    @Test
    public void testDashboard_LoggedInUser_SQLException() {
        DatabaseConnection.setThrowSQLException(true);

        insertUser("testuser", "password");

        login("testuser", "password");

        driver.get(BASE_URL + "/dashboard");

        assertTrue(driver.getCurrentUrl().endsWith("/login"));

        DatabaseConnection.setThrowSQLException(false);
    }


    private void insertUser(String username, String password) {
        try {
            PreparedStatement statement = connection.prepareStatement("INSERT INTO users (username, password) VALUES (?, ?)");
            statement.setString(1, username);
            statement.setString(2, password);
            statement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void insertWellnessData(String username, String metricName, String value) {
        try {
            PreparedStatement statement = connection.prepareStatement("INSERT INTO health_metrics (user_id, metric_name, value) SELECT id, ?, ? FROM users WHERE username = ?");
            statement.setString(1, metricName);
            statement.setString(2, value);
            statement.setString(3, username);
            statement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void login(String username, String password) {
        driver.get(BASE_URL + "/login");

        WebElement usernameField = driver.findElement(By.name("username"));
        WebElement passwordField = driver.findElement(By.name("password"));
        usernameField.sendKeys(username);
        passwordField.sendKeys(password);

        WebElement submitButton = driver.findElement(By.cssSelector("button[type='submit']"));
        submitButton.click();
    }
    public class DatabaseConnection {
        private static boolean throwSQLException = false;

        public static void setThrowSQLException(boolean value) {
            throwSQLException = value;
        }

        public static Connection getConnection() throws SQLException {
            if (throwSQLException) {
                throw new SQLException("Simulated SQLException");
            }
            return DriverManager.getConnection("jdbc:mysql://ec2-3-133-147-230.us-east-2.compute.amazonaws.com:3306/WellnessWave", "newmysqlremoteuser", "mypassword");
        }
    }
    private void deleteWellnessData(String username) throws SQLException {
        try (Connection connection = DatabaseConnection.getConnection()) {
            String query = "DELETE FROM health_metrics WHERE user_id = ?";
            try (PreparedStatement statement = connection.prepareStatement(query)) {
                statement.setLong(1, getUserIdByUsername(username));
                statement.executeUpdate();
            }
        }
    }
    private long getUserIdByUsername(String username) throws SQLException {
        long userId = -1;
        try (Connection connection = DatabaseConnection.getConnection()) {
            String query = "SELECT id FROM users WHERE username = ?";
            try (PreparedStatement statement = connection.prepareStatement(query)) {
                statement.setString(1, username);
                try (ResultSet resultSet = statement.executeQuery()) {
                    if (resultSet.next()) {
                        userId = resultSet.getLong("id");
                    }
                }
            }
        }
        return userId;
    }
    private void deleteUser(String username) throws SQLException {
        try (Connection connection = DatabaseConnection.getConnection()) {
            String query = "DELETE FROM users WHERE username = ?";
            try (PreparedStatement statement = connection.prepareStatement(query)) {
                statement.setString(1, username);
                statement.executeUpdate();
            }
        }
    }

}
