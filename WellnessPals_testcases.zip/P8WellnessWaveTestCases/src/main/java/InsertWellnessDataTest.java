import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.Duration;
import java.util.concurrent.TimeUnit;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

public class InsertWellnessDataTest {

    private WebDriver driver;
    private Connection connection;
    private final String BASE_URL = "http://ec2-3-133-147-230.us-east-2.compute.amazonaws.com:8080/WellnessWave";

    @Before
    public void setUp() {
        System.setProperty("webdriver.chrome.driver", "C:\\Users\\Zlyx\\Desktop\\webprojects\\Web Servlet Tools\\ChromeDriver\\chromedriver.exe");
        driver = new ChromeDriver();
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

        String url = "jdbc:mysql://ec2-3-133-147-230.us-east-2.compute.amazonaws.com:3306/WellnessWave";
        String username = "newmysqlremoteuser";
        String password = "mypassword";
        try {
            connection = DriverManager.getConnection(url, username, password);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @After
    public void tearDown() {
        if (driver != null) {
            driver.quit();
        }
        if (connection != null) {
            try {
                connection.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }

    @Test
    public void testInsertWellnessData() {
        driver.get(BASE_URL + "/login");

        WebElement usernameField = driver.findElement(By.name("username"));
        WebElement passwordField = driver.findElement(By.name("password"));
        usernameField.sendKeys("fred");
        passwordField.sendKeys("ward");

        WebElement submitButton = driver.findElement(By.cssSelector("button[type='submit']"));
        submitButton.click();

        Duration duration = Duration.ofSeconds(10);
        WebDriverWait wait = new WebDriverWait(driver, duration);
        wait.until(ExpectedConditions.urlContains("/dashboard"));

        WebElement insertLink = wait.until(ExpectedConditions.elementToBeClickable(By.linkText("Insert Wellness Data")));
        insertLink.click();

        wait.until(ExpectedConditions.urlContains("/insertWellnessData"));

        WebElement metricNameField = driver.findElement(By.id("metricName"));
        WebElement valueField = driver.findElement(By.id("value"));
        metricNameField.sendKeys("sleep");
        valueField.sendKeys("8");

        WebElement submitButton2 = driver.findElement(By.cssSelector("button[type='submit']"));
        submitButton2.click();

        assertTrue(driver.getCurrentUrl().endsWith("/dashboard"));

        try {
            PreparedStatement statement = connection.prepareStatement("SELECT COUNT(*) FROM health_metrics WHERE metric_name = ? and value = ?");
            statement.setString(1, "sleep");
            statement.setString(2, "8");
            ResultSet resultSet = statement.executeQuery();
            assertTrue(resultSet.next());
            int count = resultSet.getInt(1);
            assertTrue(count > 0);
        } catch (SQLException e) {
            e.printStackTrace();
            assertFalse(true);
        }
    }
    
    
    
}