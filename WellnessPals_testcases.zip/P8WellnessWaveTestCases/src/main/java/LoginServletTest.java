import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import static org.junit.Assert.assertEquals;

public class LoginServletTest {

    private WebDriver driver;
    private final String BASE_URL = "http://ec2-3-133-147-230.us-east-2.compute.amazonaws.com:8080/WellnessWave";

    @Before
    public void setUp() {
    	System.setProperty("webdriver.chrome.driver", "C:\\Users\\Zlyx\\Desktop\\webprojects\\Web Servlet Tools\\ChromeDriver\\chromedriver.exe");
        driver = new ChromeDriver();
    }

    @Test
    public void testValidLogin() {
        driver.get(BASE_URL + "/login");

        WebElement usernameField = driver.findElement(By.name("username"));
        WebElement passwordField = driver.findElement(By.name("password"));
        usernameField.sendKeys("fred");
        passwordField.sendKeys("ward");

        WebElement submitButton = driver.findElement(By.cssSelector("button[type='submit']"));
        submitButton.click();

        assertEquals(BASE_URL + "/dashboard", driver.getCurrentUrl());
    }

    @Test
    public void testInvalidLogin() {
        driver.get(BASE_URL + "/login");

        WebElement usernameField = driver.findElement(By.name("username"));
        WebElement passwordField = driver.findElement(By.name("password"));
        usernameField.sendKeys("invalid_username");
        passwordField.sendKeys("invalid_password");

        passwordField.submit();

        WebElement errorMessage = driver.findElement(By.cssSelector("p[style='color: red;']"));
        assertEquals("Invalid username or password", errorMessage.getText());
    }
    @Test
    public void testNullLogin() {
    	driver.get(BASE_URL + "/login");
    	 WebElement usernameField = driver.findElement(By.name("username"));
         WebElement passwordField = driver.findElement(By.name("password"));
         usernameField.sendKeys("");
         passwordField.sendKeys("");
         passwordField.submit();

         WebElement errorMessage = driver.findElement(By.cssSelector("p[style='color: red;']"));
         assertEquals("Invalid username or password", errorMessage.getText());
    }
    

    @After
    public void tearDown() {
        if (driver != null) {
            driver.quit();
        }
    }
}
