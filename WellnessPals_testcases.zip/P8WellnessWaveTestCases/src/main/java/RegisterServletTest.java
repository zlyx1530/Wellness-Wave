import org.junit.*;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.*;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.sql.*;
import java.time.Duration;
import java.util.concurrent.TimeUnit;

import static org.junit.Assert.*;

public class RegisterServletTest {

    private WebDriver driver;
    private Connection connection;
    private Duration duration = Duration.ofSeconds(5);
    private final String BASE_URL = "http://ec2-3-133-147-230.us-east-2.compute.amazonaws.com:8080/WellnessWave";

    @Before
    public void setUp() {
        System.setProperty("webdriver.chrome.driver", "C:\\Users\\Zlyx\\Desktop\\webprojects\\Web Servlet Tools\\ChromeDriver\\chromedriver.exe");
        driver = new ChromeDriver();
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

        String url = "jdbc:mysql://ec2-3-133-147-230.us-east-2.compute.amazonaws.com:3306/WellnessWave";
        String username = "newmysqlremoteuser";
        String password = "mypassword";
        try {
            connection = DriverManager.getConnection(url, username, password);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @After
    public void tearDown() {
        if (driver != null) {
            driver.quit();
        }
        if (connection != null) {
            try {
                connection.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }

    @Test
    public void testRegistration_Success() {
        try {
            // Delete the user if already exists
            PreparedStatement deleteStatement = connection.prepareStatement("DELETE FROM users WHERE username = ?");
            deleteStatement.setString(1, "newUser");
            deleteStatement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
            fail("SQLException occurred while deleting user");
        }

        driver.get(BASE_URL + "/register");

        WebElement usernameField = driver.findElement(By.cssSelector("input[name='username']"));
        WebElement passwordField = driver.findElement(By.cssSelector("input[name='password']"));
        usernameField.sendKeys("newUser");
        passwordField.sendKeys("password");

        WebElement submitButton = driver.findElement(By.cssSelector("button[type='submit']"));
        submitButton.click();

        assertTrue(driver.getCurrentUrl().endsWith("/login"));

        try {
            PreparedStatement statement = connection.prepareStatement("SELECT COUNT(*) FROM users WHERE username = ?");
            statement.setString(1, "newUser");
            ResultSet resultSet = statement.executeQuery();
            assertTrue(resultSet.next());
            int count = resultSet.getInt(1);
            assertTrue(count > 0);
        } catch (SQLException e) {
            e.printStackTrace();
            fail("SQLException occurred");
        }
    }


    @Test
    public void testRegistration_UsernameExists() {

        driver.get(BASE_URL + "/register");

        WebElement usernameField = driver.findElement(By.cssSelector("input[name='username']"));
        WebElement passwordField = driver.findElement(By.cssSelector("input[name='password']"));
        usernameField.sendKeys("fred");
        passwordField.sendKeys("ward");

        WebElement submitButton = driver.findElement(By.cssSelector("button[type='submit']"));
        submitButton.click();

        WebDriverWait wait = new WebDriverWait(driver, duration);
        try {
            // Wait for the registration page URL to load
            wait.until(ExpectedConditions.urlToBe(BASE_URL + "/register"));
            assertTrue(driver.getCurrentUrl().endsWith("/register"));
        } catch (TimeoutException e) {
            fail("TimeoutException occurred while waiting for registration page URL");
        }
    }



}

